PlayerMoney = class()
function PlayerMoney:__init(starting_money, starting_gold )
    getter_setter(self, "money")
    getter_setter(self, "gold")
    self:SetMoney(starting_money)
    self:SetGold(starting_gold)
end

function PlayerMoney:PlayerGetGem()
    self:SetGold(self:GetGold() + 1)
    print(string.format("You got gold! Total gold: %d", self:GetGold()))
end

function PlayerMoney:PlayerGetMoney(amount)
    self:SetMoney(self:GetMoney() + amount)
    print(string.format("You got %d money! You now have %d total.", amount, self:GetMoney()))
end

PlayerMoney = PlayerMoney(10, 2)

PlayerStats = class()
function PlayerStats:__init(vdeaths, vkills, vmurders, vmissed, vpvpkills, vpvpdeaths)
    getter_setter(self, "deaths")
    getter_setter(self, "kills")
    getter_setter(self, "murders")
    getter_setter(self, "missed")
    getter_setter(self, "pvpkills")
    getter_setter(self, "pvpdeaths")
    self:SetDeaths(vdeaths)
   self:SetKills(vkills)
   self:SetMurders(vmurders)
   self:SetMissed(vmissed)
   self:SetPvpkills(vpvpkills)
   self:SetPvpdeaths(vpvpdeaths)

end

function PlayerStats:pGetdeaths()
    self:SetDeaths(self:Getdeaths() + 1)
    print(string.format(" Total deaths: %d", self:Getdeaths()))
end

function PlayerStats:pGetkills(amount)
    self:SetKills(self:Getkills() + amount)
    print(string.format(" kills! You now have %d total.", amount, self:Getkills()))
end
function PlayerStats:pGetmurders()
    self:SetMurders(self:Getmurders() + 1)
    print(string.format(" Total murders: %d", self:Getmurders()))
end
function PlayerStats:pGetmissed()
    self:SetMissed(self:Getmissed() + 1)
    print(string.format(" Total missed: %d", self:Getmissed()))
end
function PlayerStats:pGetpvpkills()
    self:SetPvpkills(self:Getpvpkills() + 1)
    print(string.format(" Total pvpkills: %d", self:Getpvpkills()))
end
function PlayerStats:pGetpvpdeaths()
    self:SetPvpdeaths(self:Getpvpdeaths() + 1)
    print(string.format(" Total pvpdeaths: %d", self:Getpvpdeaths()))
end
PlayerStats = PlayerStats('0',0,0,0,0,0)




PlayerPowers = class()
function PlayerPowers:__init(slowmo, superjump, attack, defense, life, stamina)
    getter_setter(self, "slowmo")
    getter_setter(self, "superjump")
    self:SetSlowmo(slowmo)
    self:SetSuperjump(superjump)
end

function PlayerPowers:PlayerGetsuperjump()
    self:SetSuperjump(true)
    print("You got superjump! ")
end

function PlayerPowers:PlayerGetslowmo()
    self:SetSlowmo(true)
    print("You gotslowmo! ")
end

PlayerPowers = PlayerPowers(false, false)
