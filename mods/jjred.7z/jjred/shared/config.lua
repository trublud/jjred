JJRedConfig = {

    slowmopower = false, -- can be triggered by player
    slowmoinvis = false, -- is invisible when slow motion triggered by player
    slowmospeed = 0.3, -- half speed = 0.5
    nightvisionpower = false, -- can be triggered by player
    heatvisionpower = false, -- can be triggered by player
    slowmopowertime = 5, -- how long it lasts
    nightvisiontime = 5, -- how long it lasts
    heatvisiontime = 5, -- how long it lasts
    flashspeed = 2.5, -- how fast player runs when in slow motion
    AutoShowList = false, -- removing in next release
    powercooldown = 5, -- how long between power uses

}
JJRedConfig.Plugins= {
  ESX = true, -- only for Notifications if perferred
  showNotification = true, -- RottonV only for Notifications if perferred
  VORP = false, -- full system integration!! optional
  redemrp = true, -- only for Notifications if perferred
  FeedM = true -- only for Notifications if perferred
}
JJRedConfig.Keys = {
    RequireAiming = false, -- removing in next release
    SettingsKey = 0x4BC9DABB, -- open hud settings /jjsettings
    NightVision = 0x4BC9DABB, -- trigger power /jjpower night
    HeatVision = 0x4AF4D473, -- trigger power /jjpower heat
    SlowMo = 0x7F8D09B8 -- trigger power /jjpower slowmo
}
JJRedConfig.KeysHash = {

    -- Letters
    ["A"] = 0x7065027D,
    ["B"] = 0x4CC0E2FE,
    ["C"] = 0x9959A6F0,
    ["D"] = 0xB4E465B4,
    ["E"] = 0xCEFD9220,
    ["F"] = 0xB2F377E8,
    ["G"] = 0x760A9C6F,
    ["H"] = 0x24978A28,
    ["I"] = 0xC1989F95,
    ["J"] = 0xF3830D8E,
    -- Missing K, don't know if anything is actually bound to it
    ["L"] = 0x80F28E95,
    ["M"] = 0xE31C6A41,
    ["N"] = 0x4BC9DABB, -- Push to talk key
    ["O"] = 0xF1301666,
    ["P"] = 0xD82E0BD2,
    ["Q"] = 0xDE794E3E,
    ["R"] = 0xE30CD707,
    ["S"] = 0xD27782E3,
    -- Missing T
    ["U"] = 0xD8F73058,
    ["V"] = 0x7F8D09B8,
    ["W"] = 0x8FD015D8,
    ["X"] = 0x8CC9CD42,
    -- Missing Y
    ["Z"] = 0x26E9DC00,

    -- Symbol Keys
    ["RIGHTBRACKET"] = 0xA5BDCD3C,
    ["LEFTBRACKET"] = 0x430593AA,
    -- Mouse buttons
    ["MOUSE1"] = 0x07CE1E61,
    ["MOUSE2"] = 0xF84FA74F,
    ["MOUSE3"] = 0xCEE12B50,
    ["MWUP"] = 0x3076E97C,
    -- Modifier Keys
    ["CTRL"] = 0xDB096B85,
    ["TAB"] = 0xB238FE0B,
    ["SHIFT"] = 0x8FFC75D6,
    ["SPACEBAR"] = 0xD9D0E1C0,
    ["ENTER"] = 0xC7B5340A,
    ["BACKSPACE"] = 0x156F7119,
    ["LALT"] = 0x8AAA0AD4,
    ["DEL"] = 0x4AF4D473,
    ["PGUP"] = 0x446258B6,
    ["PGDN"] = 0x3C3DD371,
    -- Function Keys
    ["F1"] = 0xA8E3F467,
    ["F4"] = 0x1F6D95E5,
    ["F6"] = 0x3C0A40F2,
    -- Number Keys
    ["1"] = 0xE6F612E4,
    ["2"] = 0x1CE6D9EB,
    ["3"] = 0x4F49CC4C,
    ["4"] = 0x8F9F9E58,
    ["5"] = 0xAB62E997,
    ["6"] = 0xA1FDE2A6,
    ["7"] = 0xB03A913B,
    ["8"] = 0x42385422,
    -- Arrow Keys
    ["DOWN"] = 0x05CA7C52,
    ["UP"] = 0x6319DB71,
    ["LEFT"] = 0xA65EBAB4,
    ["RIGHT"] = 0xDEB34313
}

