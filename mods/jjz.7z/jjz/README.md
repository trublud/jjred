# RedEM:RP Properties

RedEM:RP Properties is a resource for RedM which allows you to own and manage properties, with an extensible module layout

## Support
To support our development you can take a look at our patreon [https://patreon.com/gdevelopment](https://patreon.com/gdevelopment) all proceeds go directly to fund the costs we incur and no profit will be gained.

We also have a Discord where you can chat, asks questions and generally it's a nice environment

[https://discord.gg/nbmTmZR](https://discord.gg/nbmTmZR)

## Requirements
- [RedEM](https://forum.cfx.re/t/essentialmode-redm-edition-redem/912798)
- [RedEM:RP](https://forum.cfx.re/t/redem-roleplay-gamemode-the-roleplay-gamemode-for-redm/915043)

## Installation

- Make sure you have everything installed from the requirements
- Drag & Drop this to your "resources" folder
- Add `ensure redemrp_properties` to your server configuration
- Start your server and done :)

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change. Also make sure to test your PR's before requesting a merge

## License
Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International Public License

For details read the "LICENSE" file, if you need to commercialize this please contact the respective authors first to discuss a private license