  
Zombie = class()

function Zombie:__init()

    LocalPlayer:GetPlayer():DisableFiring(true)

    -- LocalPlayer:RestrictAction(Control.NextCamera, true)
    LocalPlayer:RestrictAction(Control.Cover, true)
    -- Camera:LockCameraMode(CameraViewMode.FirstPerson)

    -- Increase run speed a bit since they'll be running a lot
    --LocalPlayer:GetPlayer():SetRunSprintMultiplier(1.25)

    self:StartStaminaLoop()

    self.action_timers = 
    {
        attack = Timer()
    }

    Keymap:Register("mouse_left", "mouse_button", "attack", function(args)
        if args.down then
            self:TryToAttack()
        end
    end)

    if IsTest then
        self:TestCommands()
    end

end

function Zombie:TryToAttack()
    -- TODO: put the attack timer on a per-weapon basis
    if self.action_timers.attack:GetSeconds() < 1 then return end

    self.action_timers.attack:Restart()

    -- TODO: animations should be on a per-weapon basis
    LocalPlayer:GetPed():PlayAnim({
        animDict = "anim@melee@machete@streamed_core@",
        animName = "plyr_walking_attack_a",
        flag = AnimationFlags.ANIM_FLAG_CANCELABLE,
        animTime = 0.15
    })

    local detection = MeleeActionStoneHatchet(LocalPlayer:GetPed())
    detection:DetectHits()

    Citizen.CreateThread(function()
        Wait(800)
        detection:StopDetecting()
    end)

end

function Zombie:StartStaminaLoop()
    -- Give the player infinite stamina
    Citizen.CreateThread(function()
        while true do
       --     LocalPlayer:GetPlayer():ResetStamina()
            Wait(9500)
          --  cSettingsHud:Notify("hit")
        end
    end)
end

function Zombie:TestCommands()

    RegisterCommand('anim', function()
        LocalPlayer:GetPed():PlayAnim({
            animDict = "anim@melee@machete@streamed_core@",
            animName = "plyr_walking_attack_a",
            flag = AnimationFlags.ANIM_FLAG_CANCELABLE,
            animTime = 0.15
        })
    end)

end

Zombie = Zombie()