CREATE TABLE undead (
	id char(40) NOT NULL,
	name varchar(255) NOT NULL,
	killed int unsigned NOT NULL,
	PRIMARY KEY (id)
)
