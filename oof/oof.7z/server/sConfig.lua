OOF_Config = 
{
    Deferrals = 
    {
        CheckingSteamId = "Checking Steam ID...",
        NotConnectedToSteam = "You are not connected to steam.",
        Connecting = "Connecting to awesomeness...",
        NotWhitelisted = "You are not whitelisted.",
        DuplicateName = "Someone on the server already has the name %s. Please change your name and try joining again.",
        ConnectionCancelled = "Connection cancelled.",
        WaitingInQueue = "Hey there, %s. Sorry to inform you, but the server is full! Hang on for a few moments while we get you connected.\n%s\n" ..
            "Your position in queue: %s",
        Connected = "Connected! Welcome!",
        LoadingIcon = "🔥"
    }
}