IsFiveM = true
IsRedM = false