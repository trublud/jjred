IsRedM = true
IsFiveM = false